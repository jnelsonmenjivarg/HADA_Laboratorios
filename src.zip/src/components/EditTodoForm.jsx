import React, { useState, useEffect, useRef } from "react";

export const EditTodoForm = ({ editTodo, task }) => {
  const [value, setValue] = useState(task.task || "");
  const inputRef = useRef(task.dueDate ? new Date(task.dueDate) :   null);
  const [date, setDate] = useState(task.dueDate ? new Date(task.dueDate) : null); 

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    setValue(task.task || "");
  }, [task]);

  useEffect(() => {
    setDate(task.dueDate ? new Date(task.dueDate) : null);
      }, [task]);

  const handleSubmit = (e) => {
    e.preventDefault();
    editTodo(task.id, value);
  };

  return (
    <form className="TodoForm" onSubmit={handleSubmit}>
      <input
        type="text"
        className="todo-input"
        value={value}
        placeholder="Update Task"
        onChange={(e) => setValue(e.target.value)}
        ref={inputRef}
      ></input>
      <button type="submit" className="todo-btn">
        Update Task
      </button>
    </form>
  );
};

 