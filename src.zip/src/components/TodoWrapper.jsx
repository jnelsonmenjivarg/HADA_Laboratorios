// src/components/TodoWrapper.jsx

// Importaciones de vistas
import { TodoForm } from "./TodoForm.jsx";
import { Todo } from "./Todo.jsx";
import { EditTodoForm } from "./EditTodoForm.jsx";

// Importación del hook lógico
import { useTodos } from "../hooks/usetodos.js";

export const TodoWrapper = () => {
  const {
    todos,
    addTodo,
    toggleComplete,
    deleteTodo,
    editTodo
  } = useTodos([]); // Toda la lógica está aquí

  return (
    <div className="TodoWrapper">
      <h1>Lista de cosas pendientes</h1>
      <TodoForm addTodo={addTodo} />

      {/* Mapeamos la lista de tareas */}
      {todos.map((todo) =>
        todo.isEditing ? (
          <EditTodoForm
            key={todo.id}
            editTodo={editTodo}
            task={todo}
          />
        ) : (
          <Todo
            task={todo}
            key={todo.id}
            toggleComplete={toggleComplete}
            deleteTodo={deleteTodo}
            editTodo={editTodo}
          />
        )
      )}
    </div>
  );
};
