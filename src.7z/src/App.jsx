

// src/App.jsx
import './App.css';
import { TodoWrapper } from './components/TodoWrapper.jsx';

function App() {
  return (
    <div className="App">
      <TodoWrapper />
    </div>
  );
}

export default App; 